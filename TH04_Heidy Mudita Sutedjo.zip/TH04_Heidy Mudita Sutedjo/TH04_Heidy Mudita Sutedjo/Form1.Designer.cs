﻿namespace TH04_Heidy_Mudita_Sutedjo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_TeamList = new System.Windows.Forms.Label();
            this.lbox_TeamList = new System.Windows.Forms.ListBox();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.lbl_CountryList = new System.Windows.Forms.Label();
            this.lbl_TeamList2 = new System.Windows.Forms.Label();
            this.cbox_CountryList = new System.Windows.Forms.ComboBox();
            this.cbox_TeamList = new System.Windows.Forms.ComboBox();
            this.lbl_NewTeamName = new System.Windows.Forms.Label();
            this.lbl_NewTeamCountry = new System.Windows.Forms.Label();
            this.lbl_NewTeamCity = new System.Windows.Forms.Label();
            this.btn_AddTeam = new System.Windows.Forms.Button();
            this.lbl_AddTeam = new System.Windows.Forms.Label();
            this.lbl_AddPlayer = new System.Windows.Forms.Label();
            this.btn_AddPlayer = new System.Windows.Forms.Button();
            this.lbl_NewPlayerPosition = new System.Windows.Forms.Label();
            this.lbl_NewPlayerNum = new System.Windows.Forms.Label();
            this.txtbox_NewPlayerNum = new System.Windows.Forms.TextBox();
            this.lbl_NewPlayerName = new System.Windows.Forms.Label();
            this.txtbox_NewPlayerName = new System.Windows.Forms.TextBox();
            this.cbox_NewPlayerPosition = new System.Windows.Forms.ComboBox();
            this.txtbox_NewTeamName = new System.Windows.Forms.TextBox();
            this.txtbox_NewTeamCountry = new System.Windows.Forms.TextBox();
            this.txtbox_NewTeamCity = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_TeamList
            // 
            this.lbl_TeamList.AutoSize = true;
            this.lbl_TeamList.Location = new System.Drawing.Point(12, 51);
            this.lbl_TeamList.Name = "lbl_TeamList";
            this.lbl_TeamList.Size = new System.Drawing.Size(90, 13);
            this.lbl_TeamList.TabIndex = 0;
            this.lbl_TeamList.Text = "Soccer Team List";
            // 
            // lbox_TeamList
            // 
            this.lbox_TeamList.FormattingEnabled = true;
            this.lbox_TeamList.Location = new System.Drawing.Point(15, 165);
            this.lbox_TeamList.Name = "lbox_TeamList";
            this.lbox_TeamList.Size = new System.Drawing.Size(196, 108);
            this.lbox_TeamList.TabIndex = 1;
            // 
            // btn_Remove
            // 
            this.btn_Remove.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_Remove.Location = new System.Drawing.Point(15, 279);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(62, 23);
            this.btn_Remove.TabIndex = 2;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = false;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // lbl_CountryList
            // 
            this.lbl_CountryList.AutoSize = true;
            this.lbl_CountryList.Location = new System.Drawing.Point(12, 77);
            this.lbl_CountryList.Name = "lbl_CountryList";
            this.lbl_CountryList.Size = new System.Drawing.Size(85, 13);
            this.lbl_CountryList.TabIndex = 4;
            this.lbl_CountryList.Text = "Choose Country:";
            // 
            // lbl_TeamList2
            // 
            this.lbl_TeamList2.AutoSize = true;
            this.lbl_TeamList2.Location = new System.Drawing.Point(12, 111);
            this.lbl_TeamList2.Name = "lbl_TeamList2";
            this.lbl_TeamList2.Size = new System.Drawing.Size(76, 13);
            this.lbl_TeamList2.TabIndex = 5;
            this.lbl_TeamList2.Text = "Choose Team:";
            // 
            // cbox_CountryList
            // 
            this.cbox_CountryList.FormattingEnabled = true;
            this.cbox_CountryList.Location = new System.Drawing.Point(103, 74);
            this.cbox_CountryList.Name = "cbox_CountryList";
            this.cbox_CountryList.Size = new System.Drawing.Size(121, 21);
            this.cbox_CountryList.TabIndex = 6;
            this.cbox_CountryList.SelectedIndexChanged += new System.EventHandler(this.cbox_CountryList_SelectedIndexChanged);
            // 
            // cbox_TeamList
            // 
            this.cbox_TeamList.FormattingEnabled = true;
            this.cbox_TeamList.Location = new System.Drawing.Point(103, 108);
            this.cbox_TeamList.Name = "cbox_TeamList";
            this.cbox_TeamList.Size = new System.Drawing.Size(121, 21);
            this.cbox_TeamList.TabIndex = 7;
            this.cbox_TeamList.SelectedIndexChanged += new System.EventHandler(this.cbox_TeamList_SelectedIndexChanged);
            // 
            // lbl_NewTeamName
            // 
            this.lbl_NewTeamName.AutoSize = true;
            this.lbl_NewTeamName.Location = new System.Drawing.Point(270, 74);
            this.lbl_NewTeamName.Name = "lbl_NewTeamName";
            this.lbl_NewTeamName.Size = new System.Drawing.Size(68, 13);
            this.lbl_NewTeamName.TabIndex = 8;
            this.lbl_NewTeamName.Text = "Team Name:";
            // 
            // lbl_NewTeamCountry
            // 
            this.lbl_NewTeamCountry.AutoSize = true;
            this.lbl_NewTeamCountry.Location = new System.Drawing.Point(270, 104);
            this.lbl_NewTeamCountry.Name = "lbl_NewTeamCountry";
            this.lbl_NewTeamCountry.Size = new System.Drawing.Size(76, 13);
            this.lbl_NewTeamCountry.TabIndex = 10;
            this.lbl_NewTeamCountry.Text = "Team Country:";
            // 
            // lbl_NewTeamCity
            // 
            this.lbl_NewTeamCity.AutoSize = true;
            this.lbl_NewTeamCity.Location = new System.Drawing.Point(270, 136);
            this.lbl_NewTeamCity.Name = "lbl_NewTeamCity";
            this.lbl_NewTeamCity.Size = new System.Drawing.Size(57, 13);
            this.lbl_NewTeamCity.TabIndex = 12;
            this.lbl_NewTeamCity.Text = "Team City:";
            // 
            // btn_AddTeam
            // 
            this.btn_AddTeam.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_AddTeam.Location = new System.Drawing.Point(352, 159);
            this.btn_AddTeam.Name = "btn_AddTeam";
            this.btn_AddTeam.Size = new System.Drawing.Size(55, 24);
            this.btn_AddTeam.TabIndex = 13;
            this.btn_AddTeam.Text = "Add";
            this.btn_AddTeam.UseVisualStyleBackColor = false;
            this.btn_AddTeam.Click += new System.EventHandler(this.btn_AddTeam_Click);
            // 
            // lbl_AddTeam
            // 
            this.lbl_AddTeam.AutoSize = true;
            this.lbl_AddTeam.Location = new System.Drawing.Point(349, 51);
            this.lbl_AddTeam.Name = "lbl_AddTeam";
            this.lbl_AddTeam.Size = new System.Drawing.Size(70, 13);
            this.lbl_AddTeam.TabIndex = 14;
            this.lbl_AddTeam.Text = "Adding Team";
            // 
            // lbl_AddPlayer
            // 
            this.lbl_AddPlayer.AutoSize = true;
            this.lbl_AddPlayer.Location = new System.Drawing.Point(597, 51);
            this.lbl_AddPlayer.Name = "lbl_AddPlayer";
            this.lbl_AddPlayer.Size = new System.Drawing.Size(77, 13);
            this.lbl_AddPlayer.TabIndex = 22;
            this.lbl_AddPlayer.Text = "Adding Players";
            // 
            // btn_AddPlayer
            // 
            this.btn_AddPlayer.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btn_AddPlayer.Location = new System.Drawing.Point(600, 159);
            this.btn_AddPlayer.Name = "btn_AddPlayer";
            this.btn_AddPlayer.Size = new System.Drawing.Size(55, 24);
            this.btn_AddPlayer.TabIndex = 21;
            this.btn_AddPlayer.Text = "Add";
            this.btn_AddPlayer.UseVisualStyleBackColor = false;
            this.btn_AddPlayer.Click += new System.EventHandler(this.btn_AddPlayer_Click);
            // 
            // lbl_NewPlayerPosition
            // 
            this.lbl_NewPlayerPosition.AutoSize = true;
            this.lbl_NewPlayerPosition.Location = new System.Drawing.Point(518, 136);
            this.lbl_NewPlayerPosition.Name = "lbl_NewPlayerPosition";
            this.lbl_NewPlayerPosition.Size = new System.Drawing.Size(79, 13);
            this.lbl_NewPlayerPosition.TabIndex = 20;
            this.lbl_NewPlayerPosition.Text = "Player Position:";
            // 
            // lbl_NewPlayerNum
            // 
            this.lbl_NewPlayerNum.AutoSize = true;
            this.lbl_NewPlayerNum.Location = new System.Drawing.Point(518, 104);
            this.lbl_NewPlayerNum.Name = "lbl_NewPlayerNum";
            this.lbl_NewPlayerNum.Size = new System.Drawing.Size(79, 13);
            this.lbl_NewPlayerNum.TabIndex = 18;
            this.lbl_NewPlayerNum.Text = "Player Number:";
            // 
            // txtbox_NewPlayerNum
            // 
            this.txtbox_NewPlayerNum.Location = new System.Drawing.Point(600, 101);
            this.txtbox_NewPlayerNum.Name = "txtbox_NewPlayerNum";
            this.txtbox_NewPlayerNum.Size = new System.Drawing.Size(121, 20);
            this.txtbox_NewPlayerNum.TabIndex = 17;
            // 
            // lbl_NewPlayerName
            // 
            this.lbl_NewPlayerName.AutoSize = true;
            this.lbl_NewPlayerName.Location = new System.Drawing.Point(518, 74);
            this.lbl_NewPlayerName.Name = "lbl_NewPlayerName";
            this.lbl_NewPlayerName.Size = new System.Drawing.Size(70, 13);
            this.lbl_NewPlayerName.TabIndex = 16;
            this.lbl_NewPlayerName.Text = "Player Name:";
            // 
            // txtbox_NewPlayerName
            // 
            this.txtbox_NewPlayerName.Location = new System.Drawing.Point(600, 71);
            this.txtbox_NewPlayerName.Name = "txtbox_NewPlayerName";
            this.txtbox_NewPlayerName.Size = new System.Drawing.Size(121, 20);
            this.txtbox_NewPlayerName.TabIndex = 15;
            // 
            // cbox_NewPlayerPosition
            // 
            this.cbox_NewPlayerPosition.FormattingEnabled = true;
            this.cbox_NewPlayerPosition.Location = new System.Drawing.Point(600, 132);
            this.cbox_NewPlayerPosition.Name = "cbox_NewPlayerPosition";
            this.cbox_NewPlayerPosition.Size = new System.Drawing.Size(121, 21);
            this.cbox_NewPlayerPosition.TabIndex = 23;
            // 
            // txtbox_NewTeamName
            // 
            this.txtbox_NewTeamName.Location = new System.Drawing.Point(352, 71);
            this.txtbox_NewTeamName.Name = "txtbox_NewTeamName";
            this.txtbox_NewTeamName.Size = new System.Drawing.Size(121, 20);
            this.txtbox_NewTeamName.TabIndex = 24;
            // 
            // txtbox_NewTeamCountry
            // 
            this.txtbox_NewTeamCountry.Location = new System.Drawing.Point(352, 101);
            this.txtbox_NewTeamCountry.Name = "txtbox_NewTeamCountry";
            this.txtbox_NewTeamCountry.Size = new System.Drawing.Size(121, 20);
            this.txtbox_NewTeamCountry.TabIndex = 25;
            // 
            // txtbox_NewTeamCity
            // 
            this.txtbox_NewTeamCity.Location = new System.Drawing.Point(352, 133);
            this.txtbox_NewTeamCity.Name = "txtbox_NewTeamCity";
            this.txtbox_NewTeamCity.Size = new System.Drawing.Size(121, 20);
            this.txtbox_NewTeamCity.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbox_NewTeamCity);
            this.Controls.Add(this.txtbox_NewTeamCountry);
            this.Controls.Add(this.txtbox_NewTeamName);
            this.Controls.Add(this.cbox_NewPlayerPosition);
            this.Controls.Add(this.lbl_AddPlayer);
            this.Controls.Add(this.btn_AddPlayer);
            this.Controls.Add(this.lbl_NewPlayerPosition);
            this.Controls.Add(this.lbl_NewPlayerNum);
            this.Controls.Add(this.txtbox_NewPlayerNum);
            this.Controls.Add(this.lbl_NewPlayerName);
            this.Controls.Add(this.txtbox_NewPlayerName);
            this.Controls.Add(this.lbl_AddTeam);
            this.Controls.Add(this.btn_AddTeam);
            this.Controls.Add(this.lbl_NewTeamCity);
            this.Controls.Add(this.lbl_NewTeamCountry);
            this.Controls.Add(this.lbl_NewTeamName);
            this.Controls.Add(this.cbox_TeamList);
            this.Controls.Add(this.cbox_CountryList);
            this.Controls.Add(this.lbl_TeamList2);
            this.Controls.Add(this.lbl_CountryList);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.lbox_TeamList);
            this.Controls.Add(this.lbl_TeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_TeamList;
        private System.Windows.Forms.ListBox lbox_TeamList;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.Label lbl_CountryList;
        private System.Windows.Forms.Label lbl_TeamList2;
        private System.Windows.Forms.ComboBox cbox_CountryList;
        private System.Windows.Forms.ComboBox cbox_TeamList;
        private System.Windows.Forms.Label lbl_NewTeamName;
        private System.Windows.Forms.Label lbl_NewTeamCountry;
        private System.Windows.Forms.Label lbl_NewTeamCity;
        private System.Windows.Forms.Button btn_AddTeam;
        private System.Windows.Forms.Label lbl_AddTeam;
        private System.Windows.Forms.Label lbl_AddPlayer;
        private System.Windows.Forms.Button btn_AddPlayer;
        private System.Windows.Forms.Label lbl_NewPlayerPosition;
        private System.Windows.Forms.Label lbl_NewPlayerNum;
        private System.Windows.Forms.TextBox txtbox_NewPlayerNum;
        private System.Windows.Forms.Label lbl_NewPlayerName;
        private System.Windows.Forms.TextBox txtbox_NewPlayerName;
        private System.Windows.Forms.ComboBox cbox_NewPlayerPosition;
        private System.Windows.Forms.TextBox txtbox_NewTeamName;
        private System.Windows.Forms.TextBox txtbox_NewTeamCountry;
        private System.Windows.Forms.TextBox txtbox_NewTeamCity;
    }
}

