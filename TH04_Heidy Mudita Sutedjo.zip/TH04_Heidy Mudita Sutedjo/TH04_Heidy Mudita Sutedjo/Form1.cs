﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH04_Heidy_Mudita_Sutedjo
{
    public partial class Form1 : Form
    {
        List<Team> teams = new List<Team>();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            Team juventus = new Team();
            juventus.teamName = "Juventus";
            juventus.teamCountry = "Italy";
            juventus.teamCity = "Turin";
            juventus.players.Add(new Player("Wojciech Szczęsny", "01", "GK"));
            juventus.players.Add(new Player("Mattia De Sciglio", "02", "DF"));
            juventus.players.Add(new Player("Bremer", "03", "DF"));
            juventus.players.Add(new Player("Federico Gatti Manuel Locatelli", "04", "DF"));
            juventus.players.Add(new Player("Danilo", "06", "DF"));
            juventus.players.Add(new Player("Federico Chiesa", "07", "FW"));
            juventus.players.Add(new Player("Weston McKennie", "08", "MF"));
            juventus.players.Add(new Player("Dušan Vlahović", "09", "FW"));
            juventus.players.Add(new Player("Paul Pogba", "10", "MF"));
            juventus.players.Add(new Player("Filip Kostić", "11", "MF"));
            juventus.players.Add(new Player("Alex Sandro Arkadiusz Milik", "12", "DF"));
            teams.Add(juventus);
            Team acmilan = new Team();
            acmilan.teamName = "AC Milan";
            acmilan.teamCountry = "Italy";
            acmilan.teamCity = "Milan";
            acmilan.players.Add(new Player("Davide Calabria", "02", "DF"));
            acmilan.players.Add(new Player("Ismaël Bennacer", "04", "MF"));
            acmilan.players.Add(new Player("Yacine Adli", "07", "MF"));
            acmilan.players.Add(new Player("Ruben Loftus-Cheek", "08", "MF"));
            acmilan.players.Add(new Player("Olivier Giroud", "09", "FW"));
            acmilan.players.Add(new Player("Rafael Leão", "10", "FW"));
            acmilan.players.Add(new Player("Christian Pulisic", "11", "MF"));
            acmilan.players.Add(new Player("Tijjani Reijnders", "14", "MF"));
            acmilan.players.Add(new Player("Luka Jović", "15", "FW"));
            acmilan.players.Add(new Player("Mike Maignan", "16", "GK"));
            acmilan.players.Add(new Player("Noah Okafor", "17", "FW"));
            teams.Add(acmilan); 
            Team manchester = new Team();
            manchester.teamName = "Manchester United";
            manchester.teamCountry = "England";
            manchester.teamCity = "Old Trafford";
            manchester.players.Add(new Player("Altay Bayindir", "01", "GK"));
            manchester.players.Add(new Player("Victor Lindelöf", "02", "DF"));
            manchester.players.Add(new Player("Sofyan Amrabat", "04", "MF"));
            manchester.players.Add(new Player("Harry Maguire", "05", "DF"));
            manchester.players.Add(new Player("Lisandro Martinez", "06", "DF"));
            manchester.players.Add(new Player("Mason Mount", "07", "MF"));
            manchester.players.Add(new Player("Bruno Fernandes", "08", "MF"));
            manchester.players.Add(new Player("Anthony Martial", "09", "FW"));
            manchester.players.Add(new Player("Marcus Rashford", "10", "FW"));
            manchester.players.Add(new Player("Rasmus Højlund", "11", "FW"));
            manchester.players.Add(new Player("Tyrell Malacia", "12", "DF"));
            teams.Add(manchester);
            foreach (Team tim in teams)
            {
                bool sama = false;
                foreach (string item in cbox_CountryList.Items)
                {
                    if (tim.teamCountry.ToString() == item)
                    {
                        sama = true;
                    }
                }
                if (sama == false)
                {
                    cbox_CountryList.Items.Add(tim.teamCountry);
                }
            }
            cbox_NewPlayerPosition.Items.Add("GK");
            cbox_NewPlayerPosition.Items.Add("DF");
            cbox_NewPlayerPosition.Items.Add("MF");
            cbox_NewPlayerPosition.Items.Add("FW");
        }

        private void cbox_CountryList_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbox_TeamList.Items.Clear();
            foreach (Team tim in teams)
            {
                if (tim.teamCountry.ToString() == cbox_CountryList.SelectedItem)
                {
                    cbox_TeamList.Items.Add(tim.teamName);
                }
            }
        }

        private void cbox_TeamList_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbox_TeamList.Items.Clear();
            foreach (Team tim in teams)
            {
                if (tim.teamName.ToString() == cbox_TeamList.SelectedItem)
                {
                    foreach (Player player in tim.players)
                    {
                        lbox_TeamList.Items.Add("(" + player.playerNum + ") " + player.playerName + ", " + player.playerPos);
                    }
                }
            }
        }

        private void btn_Remove_Click(object sender, EventArgs e)
        {
            if (lbox_TeamList.SelectedItem != null)
            {
                foreach (Team tim in teams)
                {
                    if (tim.teamName.ToString() == cbox_TeamList.SelectedItem)
                    {
                        if(tim.players.Count <= 11)
                        {
                            MessageBox.Show("Unable to remove player, players cannot be less than 11", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            int count = 0;
                            int index = 0;
                            foreach (Player player in tim.players)
                            {
                                count++;
                                if (player.playerNum == lbox_TeamList.SelectedItem.ToString().Substring(1, 2))
                                {
                                    index = count;
                                }
                            }
                            tim.players.RemoveAt(index - 1);
                            lbox_TeamList.Items.Clear();
                            foreach (Player player in tim.players)
                            {
                                lbox_TeamList.Items.Add("(" + player.playerNum + ") " + player.playerName + ", " + player.playerPos);
                            }
                        }
                    }
                }
            }
        }

        private void btn_AddTeam_Click(object sender, EventArgs e)
        {
            bool sama = false;
            if (txtbox_NewTeamName.Text == "" || txtbox_NewTeamCountry.Text == "" || txtbox_NewTeamCity.Text == "")
            {
                MessageBox.Show("All fields should be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                foreach (Team tim in teams)
                {
                    if (txtbox_NewTeamName.Text.ToLower() == tim.teamName.ToLower() && txtbox_NewTeamCity.Text.ToLower() == tim.teamCity.ToLower() && txtbox_NewTeamCountry.Text.ToLower() == tim.teamCountry.ToLower())
                    {
                        sama = true;
                    }
                }
                if (sama == true)
                {
                    MessageBox.Show("Team already exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    teams.Add(new Team(txtbox_NewTeamName.Text, txtbox_NewTeamCountry.Text, txtbox_NewTeamCity.Text));
                    txtbox_NewTeamName.Clear();
                    txtbox_NewTeamCountry.Clear();
                    txtbox_NewTeamCity.Clear();
                    foreach (Team tim in teams)
                    {
                        bool same = false;
                        foreach (string item in cbox_CountryList.Items)
                        {
                            if (tim.teamCountry.ToString() == item)
                            {
                                same = true;
                            }
                        }
                        if (same == false)
                        {
                            cbox_CountryList.Items.Add(tim.teamCountry);
                        }
                    }
                }
            }
        }

        private void btn_AddPlayer_Click(object sender, EventArgs e)
        {
            if(txtbox_NewPlayerName.Text == "" || txtbox_NewPlayerNum.Text == "" || cbox_NewPlayerPosition.SelectedItem == null)
            {
                MessageBox.Show("All fields should be filled", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                foreach (Team tim in teams)
                {
                    if (tim.teamName.ToString() == cbox_TeamList.SelectedItem)
                    {
                        bool sama = false;
                        foreach (Player player in tim.players)
                        {
                            if (player.playerNum.ToString() == txtbox_NewPlayerNum.Text)
                            {
                                sama = true;
                            }
                        }
                        if (sama == true)
                        {
                            MessageBox.Show("Player with same number is found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            tim.players.Add(new Player(txtbox_NewPlayerName.Text, txtbox_NewPlayerNum.Text, cbox_NewPlayerPosition.SelectedItem.ToString()));
                            txtbox_NewPlayerName.Clear();
                            txtbox_NewPlayerNum.Clear();
                            lbox_TeamList.Items.Clear();
                            foreach (Player player in tim.players)
                            {
                                lbox_TeamList.Items.Add("(" + player.playerNum + ") " + player.playerName + ", " + player.playerPos);
                            }
                        }
                    }
                }
            }
        }
    }
}
